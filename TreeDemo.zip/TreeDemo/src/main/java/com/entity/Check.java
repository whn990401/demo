package com.entity;


import javax.persistence.*;

@Entity
@Table(name = "check01")
public class Check {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    @Column(name = "pid")
    private Integer pId;
    private String icon;
    @Column(name = "chkdisabled")
    private String chkDisabled;
    private String open;

    public Check() {
    }

    public Check(String name, Integer pId,  String icon,String chkDisabled,String open) {
        this.name = name;
        this.pId = pId;
        this.icon = icon;
        this.chkDisabled=chkDisabled;
        this.open=open;
    }

    public String getOpen() {
        return open;
    }

    public void setOpen(String open) {
        this.open = open;
    }

    @Override
    public String toString() {
        return "Check{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", pId=" + pId +
                ", icon='" + icon + '\'' +
                ", chkDisabled='" + chkDisabled + '\'' +
                ", open='" + open + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getpId() {
        return pId;
    }

    public void setpId(Integer pId) {
        this.pId = pId;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getChkDisabled() {
        return chkDisabled;
    }

    public void setChkDisabled(String chkDisabled) {
        this.chkDisabled = chkDisabled;
    }
}

