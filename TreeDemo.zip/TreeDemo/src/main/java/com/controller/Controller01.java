package com.controller;

import com.dao.CheckDao;
import com.dao.IconDao;
import com.entity.Check;
import com.entity.Icon;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Controller
public class Controller01 {
    @Autowired
    private CheckDao checkDao;
    @Autowired
    private IconDao iconDao;

    @RequestMapping("/index")
    public String index(){
        return "demo01";
    }


    //添加节点
    @RequestMapping(value = "/addcheck",method = RequestMethod.GET)
    @ResponseBody
    public Map<String,Object> addUser(Check check){
        check.setChkDisabled("true");
        checkDao.save(check);
        Map<String,Object> map=new HashMap<>();
        map.put("id",checkDao.findAdd());
        return map;
    }

    //修改节点
    @RequestMapping("/updatecheck")
    public String updatecheck(Check check){
        Integer id=check.getId();
        String name=check.getName();
        checkDao.update(id,name);
        return "demo01";
    }

    //右键修改节点
    @RequestMapping(value = "/updatecheck02",method = RequestMethod.POST)
    public String updatecheck02(Check check){
        Integer id=check.getId();
        String name=check.getName();
        checkDao.update(id,name);
        return "demo01";
    }

    //删除节点
    @RequestMapping("/deletecheck")
    public String deleteUser(Integer id){
        checkDao.deleteByPid(id);
        return "demo01";
    }
    //清空子节点
    @RequestMapping("/delete")
    public String delete(Integer pId){
        checkDao.deleteByPId(pId);
        return "demo01";
    }
    //移到节点
    @RequestMapping("/inner")
    public String inner(Integer pId,Integer id){
        checkDao.updatePId(id,pId);
        return "demo01";
    }

    //默认展开
    @RequestMapping("/open")
    public String open(Integer id){
        checkDao.open(id);
        return "demo01";
    }


    @RequestMapping("/findAll")
    @ResponseBody
    public Map<String,Object> findAll(Model model){
        List<Check> checks = checkDao.findAll();
        Map<String,Object> map=new HashMap<>();
        map.put("checks",checks);
        return map;
    }

    @RequestMapping("/findicon")
    public Map<String,Object> findicon(Model model){
        List<Icon> icons = iconDao.findAll();
        Map<String,Object> map=new HashMap<>();
        map.put("icons",icons);
        return map;
    }





}
