package com.dao;

import com.entity.Icon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;


public interface IconDao extends JpaRepository<Icon,Integer>, JpaSpecificationExecutor<Icon> {
}
