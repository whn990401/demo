package com.dao;


import com.entity.Check;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface CheckDao extends JpaRepository<Check,Integer>, JpaSpecificationExecutor<Check> {
    //删除节点及子节点
    @Query(value = "delete from check01  where id=?1 or pid = ?1",nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByPid(Integer id);

    //清空子节点
    @Query(value = "delete from check01  where pid = ?1",nativeQuery = true)
    @Modifying
    @Transactional
    void deleteByPId(Integer pId);


    //查询新添加节点id
    @Query(value = "select max(id) from check01",nativeQuery = true)
    Integer findAdd();

    //修改节点名字
    @Query(value = "update check01 set name=?2 where id=?1",nativeQuery = true)
    @Modifying
    @Transactional
    void update(Integer id,String name);

    //设置默认展开
    @Query(value = "update check01 set `open`='true' where id=?1",nativeQuery = true)
    @Modifying
    @Transactional
    void open(Integer id);

    //移到节点
    @Query(value = "update check01 set pid=?2 where id=?1",nativeQuery = true)
    @Modifying
    @Transactional
    void updatePId(Integer id,Integer pid);
}
